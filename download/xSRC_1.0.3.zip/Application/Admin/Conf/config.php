<?php

return array(
    'TMPL_PARSE_STRING' => array(
	'__STATIC__' => __ROOT__.'/Public/Static/',),
	'SESSION_OPTIONS' => array(
		'expire' => 8000,
	),
);
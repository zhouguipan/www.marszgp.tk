<?php
return array('DB_TYPE'               =>  'mysql',
'DB_HOST'               =>  '127.0.0.1',
'DB_NAME'               =>  'xsrc',
'DB_USER'               =>  'root',
'DB_PWD'                =>  'root',
'DB_PORT'               =>  '3306',
'DB_FIELDS_CACHE'       =>  true,
'DB_CHARSET'            =>  'utf8',
);